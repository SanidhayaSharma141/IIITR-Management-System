where date(EnterDate)=CURDATE();
date(EnterDate)=CURDATE()-1